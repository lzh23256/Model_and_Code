close all;
% g=-1.4039;
% k=-5881;
% g=-2.9;
% k=-4097;
%     try
%         smodel = sim('PMSM_sfunction');
%         figure(1);
%         T=[1:2001]*0.000050;
%         plot(T,TL);
%         hold on;
%         plot(T,TL_);
%         error=TL_-TL;
%         % figure(2);
%         % plot(T,error);
%         error2=error(1000:end);
%         T2=[1:1002]*0.000050;
%         ITAE=trapz(T, T'.*abs(error))     % ITAE
% %         ITAE=trapz(T2, T2'.*abs(error2))
%     catch
%         ITAE = 1;%无解给定个大值
%     end
g=-2.7;
k=-9905;
    try
        smodel = sim('CurrentIdentification');
        figure(1);
        T=[1:6001]*0.000050;
        plot(T,smodel.TL);
        hold on;
        plot(T,smodel.TL_);
        error=smodel.TL_-smodel.TL;
        figure(2);
        plot(T,error);
        error2=error(1000:end);
        T2=[1:1002]*0.000050;
        ITAE=trapz(T, T'.*abs(error))     % ITAE
        figure(3);
        plot(T,smodel.rpmset);
        hold on;
        plot(T,smodel.rpmfb);
%         ITAE=trapz(T2, T2'.*abs(error2))
    catch
        ITAE = 1;%无解给定个大值
    end