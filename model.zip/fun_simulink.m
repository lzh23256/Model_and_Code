function ITAE=fun_simulink(pop)
% g=pop(1)
% %g=-1.4039;
% assignin('base','g',g);
% k=pop(2)
% assignin('base','k',k);
% %k=-4000;
% try
%     smodel = sim('PMSM_sfunction');
%     T=[1:2001]*0.000050;
%     error=TL_-TL;
%     ITAE=trapz(T, T'.*abs(error))     % ITAE
% catch
%     ITAE = 1;%无解给定个大值
% end

g=pop(1)
%g=-1.4039;
assignin('base','g',g);
k=pop(2)
assignin('base','k',k);
%k=-4000;
try
    smodel = sim('CurrentIdentification');
    T=[1:6001]*0.000050;
    error=smodel.TL_-smodel.TL;
    ITAE=trapz(T, T'.*abs(error))     % ITAE
catch
    ITAE = 1%无解给定个大值
end