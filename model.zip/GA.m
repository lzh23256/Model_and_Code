ObjectiveFunction = @fun_simulink;
nvars = 2;%变量个数
% LB = [-10,-10000];%定义域下限
% UB = [0,0];%定义域上限
% g=-1.4039;
LB = [-10,-10000];%定义域下限
UB = [0,-1000];%定义域上限
% options = optimoptions( 'ga' , 'InitialPopulationMatrix' ,[0.314380749971695,0.841418426840263], 'PlotFcns',@gaplotbestf,'UseParallel',true);
options = optimoptions( 'ga' , 'PlotFcns',@gaplotbestf);


[xout,fval] = ga(ObjectiveFunction,nvars,[],[],[],[],LB,UB,[],options)%调用ga函数
